-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 14, 2021 at 10:44 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rfidui`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_daftarrfid`
--

CREATE TABLE `tb_daftarrfid` (
  `id` int(100) NOT NULL,
  `rfid` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `telepon` varchar(100) NOT NULL,
  `saldo` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_daftarrfid`
--

INSERT INTO `tb_daftarrfid` (`id`, `rfid`, `nama`, `alamat`, `telepon`, `saldo`) VALUES
(1, 'ASDF123', 'admin', 'indonesia', '1234', 0),
(2, 'A732894B', 'DAFFA', 'INDONESIA', '08263832', 3031131),
(3, '2AA5B715', 'ARLAND', 'JAUH', '0816283', 0),
(7, 'AA89015', 'dyfy', 't7t7', '97986', 15000),
(8, 'ET33', 'CSACA', 'CACA', '08674', 123456);

-- --------------------------------------------------------

--
-- Table structure for table `tb_edit`
--

CREATE TABLE `tb_edit` (
  `lokasi` varchar(100) NOT NULL,
  `harga` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_edit`
--

INSERT INTO `tb_edit` (`lokasi`, `harga`) VALUES
('cibubur', 5000),
('padalarang', 10000);

-- --------------------------------------------------------

--
-- Table structure for table `tb_monitoring`
--

CREATE TABLE `tb_monitoring` (
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` varchar(100) NOT NULL,
  `rfid` varchar(100) NOT NULL,
  `lokasi` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_monitoring`
--

INSERT INTO `tb_monitoring` (`tanggal`, `status`, `rfid`, `lokasi`) VALUES
('2021-12-14 08:53:47', 'Transaksi Sukses', 'A732894B', 'cibubur');

-- --------------------------------------------------------

--
-- Table structure for table `tb_simpan`
--

CREATE TABLE `tb_simpan` (
  `no` int(100) NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `nama` varchar(100) NOT NULL,
  `rfid` varchar(100) NOT NULL,
  `lokasi` varchar(100) NOT NULL,
  `saldoawal` int(100) NOT NULL,
  `saldoakhir` int(100) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_simpan`
--

INSERT INTO `tb_simpan` (`no`, `tanggal`, `nama`, `rfid`, `lokasi`, `saldoawal`, `saldoakhir`, `status`) VALUES
(482, '2021-12-09 16:25:56', 'Tidak terdaftar', '8A375A1A', 'cibubur', 0, 0, 'ID Belum Terdaftar'),
(483, '2021-12-09 16:27:31', 'admin', 'ASDF123', 'padalarang', 0, 0, 'Saldo Tidak Cukup'),
(484, '2021-12-09 16:27:37', 'Tidak terdaftar', 'AF123', 'padalarang', 0, 0, 'ID Belum Terdaftar'),
(485, '2021-12-09 16:28:18', 'Tidak terdaftar', 'AF123', 'padalarang', 0, 0, 'ID Belum Terdaftar'),
(486, '2021-12-09 16:28:47', 'Tidak terdaftar', '8A375A1A', 'cibubur', 0, 0, 'ID Belum Terdaftar'),
(487, '2021-12-09 16:28:51', 'dyfy', 'AA89015', 'cibubur', 0, 0, 'Saldo Tidak Cukup'),
(488, '2021-12-09 16:28:55', 'Tidak terdaftar', '8A375A1A', 'cibubur', 0, 0, 'ID Belum Terdaftar'),
(489, '2021-12-09 16:30:05', 'Tidak terdaftar', '8A375A1A', 'cibubur', 0, 0, 'ID Belum Terdaftar'),
(490, '2021-12-09 16:30:09', 'Tidak terdaftar', 'AF123', 'padalarang', 0, 0, 'ID Belum Terdaftar'),
(491, '2021-12-09 16:30:54', 'Tidak terdaftar', '8A375A1A', 'cibubur', 0, 0, 'ID Belum Terdaftar'),
(492, '2021-12-09 16:30:59', 'dyfy', 'AA89015', 'cibubur', 0, 0, 'Saldo Tidak Cukup'),
(493, '2021-12-09 16:31:30', 'Tidak terdaftar', 'AF123', 'padalarang', 0, 0, 'ID Belum Terdaftar'),
(494, '2021-12-09 16:32:19', 'Tidak terdaftar', '8A375A1A', 'cibubur', 0, 0, 'ID Belum Terdaftar'),
(495, '2021-12-09 16:32:21', 'Tidak terdaftar', '8A375A1A', 'cibubur', 0, 0, 'ID Belum Terdaftar'),
(496, '2021-12-09 16:32:23', 'Tidak terdaftar', '8A375A1A', 'cibubur', 0, 0, 'ID Belum Terdaftar'),
(497, '2021-12-09 16:32:27', 'Tidak terdaftar', 'AF123', 'padalarang', 0, 0, 'ID Belum Terdaftar'),
(498, '2021-12-09 16:33:01', 'Tidak terdaftar', '8A375A1A', 'cibubur', 0, 0, 'ID Belum Terdaftar'),
(499, '2021-12-09 16:33:11', 'Tidak terdaftar', '8A375A1A', 'cibubur', 0, 0, 'ID Belum Terdaftar'),
(500, '2021-12-09 16:34:57', 'dyfy', 'AA89015', 'cibubur', 0, 0, 'Saldo Tidak Cukup'),
(501, '2021-12-09 16:45:25', 'Tidak terdaftar', '8A375A1A', 'cibubur', 0, 0, 'ID Belum Terdaftar'),
(502, '2021-12-09 16:45:28', 'dyfy', 'AA89015', 'cibubur', 0, 0, 'Saldo Tidak Cukup'),
(503, '2021-12-09 16:45:46', 'dyfy', 'AA89015', 'cibubur', 1000000, 995000, 'Transaksi Sukses'),
(504, '2021-12-09 16:45:50', 'dyfy', 'AA89015', 'cibubur', 995000, 990000, 'Transaksi Sukses'),
(505, '2021-12-09 16:45:54', 'Tidak terdaftar', '8A375A1A', 'cibubur', 0, 0, 'ID Belum Terdaftar'),
(506, '2021-12-09 16:45:57', 'Tidak terdaftar', '8A375A1A', 'cibubur', 0, 0, 'ID Belum Terdaftar'),
(507, '2021-12-09 16:46:00', 'dyfy', 'AA89015', 'cibubur', 990000, 985000, 'Transaksi Sukses'),
(508, '2021-12-09 16:47:20', 'Tidak terdaftar', '8A375A1A', 'cibubur', 0, 0, 'ID Belum Terdaftar'),
(509, '2021-12-09 16:47:24', 'dyfy', 'AA89015', 'cibubur', 985000, 980000, 'Transaksi Sukses'),
(510, '2021-12-09 16:47:28', 'dyfy', 'AA89015', 'cibubur', 980000, 975000, 'Transaksi Sukses'),
(511, '2021-12-09 16:49:17', 'Tidak terdaftar', 'AF3', 'Tidak Ada', 0, 0, 'KESALAHAN DATA'),
(512, '2021-12-09 17:07:23', 'Tidak terdaftar', 'AF3', 'Tidak Ada', 0, 0, 'KESALAHAN DATA'),
(513, '2021-12-09 17:08:17', 'dyfy', 'AA89015', 'cibubur', 975000, 970000, 'Transaksi Sukses'),
(514, '2021-12-09 17:08:24', 'Tidak terdaftar', '8A375A1A', 'cibubur', 0, 0, 'ID Belum Terdaftar'),
(515, '2021-12-09 17:09:22', 'Tidak terdaftar', '8A375A1A', 'cibubur', 0, 0, 'ID Belum Terdaftar'),
(516, '2021-12-09 17:09:26', 'dyfy', 'AA89015', 'cibubur', 970000, 965000, 'Transaksi Sukses'),
(517, '2021-12-09 17:09:58', 'dyfy', 'AA89015', 'cibubur', 965000, 960000, 'Transaksi Sukses'),
(518, '2021-12-09 17:10:01', 'Tidak terdaftar', '8A375A1A', 'cibubur', 0, 0, 'ID Belum Terdaftar'),
(519, '2021-12-09 17:11:58', 'dyfy', 'AA89015', 'cibubur', 960000, 955000, 'Transaksi Sukses'),
(520, '2021-12-09 17:13:24', 'dyfy', 'AA89015', 'cibubur', 955000, 950000, 'Transaksi Sukses'),
(521, '2021-12-09 17:13:32', 'Tidak terdaftar', '8A375A1A', 'cibubur', 0, 0, 'ID Belum Terdaftar'),
(522, '2021-12-09 17:14:35', 'dyfy', 'AA89015', 'cibubur', 950000, 945000, 'Transaksi Sukses'),
(523, '2021-12-09 17:14:44', 'Tidak terdaftar', '8A375A1A', 'cibubur', 0, 0, 'ID Belum Terdaftar'),
(524, '2021-12-09 17:16:07', 'Tidak terdaftar', '8A375A1A', 'cibubur', 0, 0, 'ID Belum Terdaftar'),
(525, '2021-12-09 17:16:11', 'dyfy', 'AA89015', 'cibubur', 945000, 940000, 'Transaksi Sukses'),
(526, '2021-12-09 17:18:03', 'Tidak terdaftar', '8A375A1A', 'cibubur', 0, 0, 'ID Belum Terdaftar'),
(527, '2021-12-09 17:18:10', 'dyfy', 'AA89015', 'cibubur', 940000, 935000, 'Transaksi Sukses'),
(528, '2021-12-09 17:18:15', 'dyfy', 'AA89015', 'cibubur', 935000, 930000, 'Transaksi Sukses'),
(529, '2021-12-09 17:18:18', 'Tidak terdaftar', '8A375A1A', 'cibubur', 0, 0, 'ID Belum Terdaftar'),
(530, '2021-12-09 17:19:54', 'dyfy', 'AA89015', 'cibubur', 930000, 925000, 'Transaksi Sukses'),
(531, '2021-12-09 17:20:00', 'Tidak terdaftar', '8A375A1A', 'cibubur', 0, 0, 'ID Belum Terdaftar'),
(532, '2021-12-09 17:20:05', 'dyfy', 'AA89015', 'cibubur', 925000, 920000, 'Transaksi Sukses'),
(533, '2021-12-09 17:20:09', 'dyfy', 'AA89015', 'cibubur', 920000, 915000, 'Transaksi Sukses'),
(534, '2021-12-09 17:20:12', 'Tidak terdaftar', '8A375A1A', 'cibubur', 0, 0, 'ID Belum Terdaftar'),
(535, '2021-12-09 17:43:38', 'Tidak terdaftar', '8A375A1A', 'cibubur', 0, 0, 'ID Belum Terdaftar'),
(536, '2021-12-09 17:43:46', 'dyfy', 'AA89015', 'cibubur', 915000, 910000, 'Transaksi Sukses'),
(537, '2021-12-09 17:43:52', 'dyfy', 'AA89015', 'cibubur', 910000, 905000, 'Transaksi Sukses'),
(538, '2021-12-09 17:43:58', 'dyfy', 'AA89015', 'cibubur', 905000, 900000, 'Transaksi Sukses'),
(539, '2021-12-09 18:24:56', 'dyfy', 'AA89015', 'cibubur', 900000, 895000, 'Transaksi Sukses'),
(540, '2021-12-09 18:25:03', 'Tidak terdaftar', '8A375A1A', 'cibubur', 0, 0, 'ID Belum Terdaftar'),
(541, '2021-12-09 18:25:08', 'Tidak terdaftar', '8A375A1A', 'cibubur', 0, 0, 'ID Belum Terdaftar'),
(542, '2021-12-09 18:25:27', 'dyfy', 'AA89015', 'cibubur', 895000, 890000, 'Transaksi Sukses'),
(543, '2021-12-09 18:25:53', 'dyfy', 'AA89015', 'cibubur', 10000, 5000, 'Transaksi Sukses'),
(544, '2021-12-09 18:25:57', 'dyfy', 'AA89015', 'cibubur', 5000, 0, 'Transaksi Sukses'),
(545, '2021-12-09 18:26:01', 'dyfy', 'AA89015', 'cibubur', 0, 0, 'Saldo Tidak Cukup'),
(546, '2021-12-09 18:26:07', 'dyfy', 'AA89015', 'cibubur', 0, 0, 'Saldo Tidak Cukup'),
(547, '2021-12-09 18:27:08', 'Tidak terdaftar', '8A375A1A', 'cibubur', 0, 0, 'ID Belum Terdaftar'),
(548, '2021-12-09 18:27:13', 'dyfy', 'AA89015', 'cibubur', 0, 0, 'Saldo Tidak Cukup'),
(549, '2021-12-09 19:15:44', 'Tidak terdaftar', '8A375A1A', 'cibubur', 0, 0, 'ID Belum Terdaftar'),
(550, '2021-12-09 19:15:53', 'dyfy', 'AA89015', 'cibubur', 0, 0, 'Saldo Tidak Cukup'),
(551, '2021-12-09 19:15:57', 'Tidak terdaftar', '8A375A1A', 'cibubur', 0, 0, 'ID Belum Terdaftar'),
(552, '2021-12-09 19:16:08', 'dyfy', 'AA89015', 'cibubur', 0, 0, 'Saldo Tidak Cukup'),
(553, '2021-12-09 19:42:24', 'Tidak terdaftar', '8A375A1A', 'cibubur', 0, 0, 'ID Belum Terdaftar'),
(554, '2021-12-09 19:42:30', 'dyfy', 'AA89015', 'cibubur', 0, 0, 'Saldo Tidak Cukup'),
(555, '2021-12-09 19:42:34', 'dyfy', 'AA89015', 'cibubur', 0, 0, 'Saldo Tidak Cukup'),
(556, '2021-12-09 19:42:38', 'Tidak terdaftar', '8A375A1A', 'cibubur', 0, 0, 'ID Belum Terdaftar'),
(557, '2021-12-09 19:42:42', 'dyfy', 'AA89015', 'cibubur', 0, 0, 'Saldo Tidak Cukup'),
(558, '2021-12-09 19:43:04', 'dyfy', 'AA89015', 'cibubur', 50000, 45000, 'Transaksi Sukses'),
(559, '2021-12-09 19:43:09', 'dyfy', 'AA89015', 'cibubur', 45000, 40000, 'Transaksi Sukses'),
(560, '2021-12-10 02:50:10', 'dyfy', 'AA89015', 'cibubur', 40000, 35000, 'Transaksi Sukses'),
(561, '2021-12-10 02:51:56', 'dyfy', 'AA89015', 'cibubur', 35000, 30000, 'Transaksi Sukses'),
(562, '2021-12-10 02:55:10', 'dyfy', 'AA89015', 'cibubur', 30000, 25000, 'Transaksi Sukses'),
(563, '2021-12-10 02:55:16', 'dyfy', 'AA89015', 'cibubur', 25000, 20000, 'Transaksi Sukses'),
(564, '2021-12-10 02:55:22', 'dyfy', 'AA89015', 'cibubur', 20000, 15000, 'Transaksi Sukses'),
(565, '2021-12-10 02:55:32', 'Tidak terdaftar', '8A375A1A', 'cibubur', 0, 0, 'ID Belum Terdaftar'),
(566, '2021-12-14 08:22:37', 'Tidak terdaftar', '8A375A1A', 'Tidak Ada', 0, 0, 'KESALAHAN DATA'),
(567, '2021-12-14 08:23:33', 'Tidak terdaftar', '8A375A1A', 'cibubur', 0, 0, 'ID Belum Terdaftar'),
(568, '2021-12-14 08:36:25', 'DAFFA', 'A732894B', 'cibubur', 3041131, 3036131, 'Transaksi Sukses'),
(569, '2021-12-14 08:53:47', 'DAFFA', 'A732894B', 'cibubur', 3036131, 3031131, 'Transaksi Sukses');

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `id` int(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin'),
(2, 'user1', 'user1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_daftarrfid`
--
ALTER TABLE `tb_daftarrfid`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_edit`
--
ALTER TABLE `tb_edit`
  ADD PRIMARY KEY (`harga`);

--
-- Indexes for table `tb_simpan`
--
ALTER TABLE `tb_simpan`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_daftarrfid`
--
ALTER TABLE `tb_daftarrfid`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tb_edit`
--
ALTER TABLE `tb_edit`
  MODIFY `harga` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10001;

--
-- AUTO_INCREMENT for table `tb_simpan`
--
ALTER TABLE `tb_simpan`
  MODIFY `no` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=570;

--
-- AUTO_INCREMENT for table `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

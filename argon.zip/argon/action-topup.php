<?php

    require "koneksidb.php";
	date_default_timezone_set('Asia/Jakarta');
    $tgl=date("Y-m-d G:i:s");

    if ($_POST['Submit'] == "Submit") {
        $rfid            = $_POST['rfid'];
        $inputsaldo           = $_POST['saldo'];
		
		
		//AMBIL DATA SALDO AWAL
   	  	$getsaldo = query("SELECT * FROM tb_daftarrfid WHERE rfid='$rfid'" )[0];
		$nama = $getsaldo['nama'];
		$saldo = $getsaldo['saldo'];
		$updatesaldo=$saldo+$inputsaldo; 
		
		//Menambah Saldo
        //Masukan data ke Table
        $input = "UPDATE  tb_daftarrfid SET saldo=saldo+'$inputsaldo' WHERE rfid='$rfid' ";
        $koneksi->query($input);
		
		//Log data saldo
		$input = "INSERT INTO tb_logsaldo (tanggal,rfid, nama, saldo, tambahsaldo, saldo_akhir) VALUES 
		('" . $tgl . "','" . $rfid . "', '" . $nama . "', '" . $saldo . "', '" . $inputsaldo . "', '" . $updatesaldo . "')";
        $koneksi->query($input);

        header("Location: topup.php?pesan=berhasil");
    }

?>
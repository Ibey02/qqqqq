<?php 
   
   require "koneksidb.php";

   $ambilrfid	 = $_GET["rfid"];
   $ambillokasi = $_GET["lokasi"];
   $ambilgolongan=$_GET["golongan"];
   date_default_timezone_set('Asia/Jakarta');
   $tgl=date("Y-m-d G:i:s");
   error_reporting(0);
   //null_reporting(0);
   
   


//AMBIL DATA tb_daftarrfid
$data=query("SELECT *FROM tb_daftarrfid WHERE rfid='$ambilrfid'")[0];
$nama=$data['nama'];
$saldo=$data['saldo'];
$id=$data['id'];


//AMBIL DATA tb_edit
$edit=query("SELECT * FROM tb_edit WHERE lokasi='$ambillokasi' ")[0];
$harga1=$edit['mobil'];
$harga2=$edit['bis'];





        
 //ID DAN TOL TERDAFTAR
   if ($data > 0 and $edit > 0){
			
			if ($saldo >= $harga1 and $ambilgolongan=="mobil"){
			$saldo_akhir = $saldo - $harga1;				
				if ($saldo_akhir >= 0) {
				$harga3=$harga1;
			
            mysqli_query($koneksi,"UPDATE tb_daftarrfid SET saldo= '$saldo_akhir' WHERE rfid='$ambilrfid'");
		   			$print_hasil = "Sukses";
	   			} else {
		   			$print_hasil = "Saldo tidak cukup";
	   			}
			}
			
				elseif ($saldo >= $harga2 and $ambilgolongan=="bis"){
				$saldo_akhir = $saldo - $harga2;
				if ($saldo_akhir >= 0) {
				$harga3=$harga2;
		
            mysqli_query($koneksi,"UPDATE tb_daftarrfid SET saldo= '$saldo_akhir' WHERE rfid='$ambilrfid'");
		   			$print_hasil = "Sukses";
	   			} else {
		   			$print_hasil = "Saldo tidak cukup";
	   			}

	    	} else {
				$saldo_akhir = $saldo;
				$print_hasil = "Saldo Tidak Cukup";
	    	}
   
			
  
	//ID TIDAK & TOL TERDAFTAR		
	} elseif ($data == 0 and $edit > 0 ){
	
   $datadummy=array('id'=>'0','rfid'=>$ambilrfid,'nama'=>'Tidak terdaftar','alamat'=>'Tidak terdaftar','telepon'=>'Tidak terdaftar','saldo'=>'0','tanggal'=>$tgl,'status'=>'ID Belum Terdaftar');
   $result = json_encode($datadummy);
   echo $result;
   $id="0";
   $print_hasil = "ID Belum Terdaftar";
   $nama="Tidak terdaftar";
   $saldo="0";
   $saldo_akhir="0";
	//ID TERDAFTAR & TOL TIDAK
	} elseif ($data > 0 and $edit == 0 ){
		$saldo_akhir = $saldo;
        $print_hasil = "Nama Tol Tidak Terdaftar";
	//ID & TOL TIDAK TERDAFTAR	
	} else {
		$saldo_akhir = $saldo;
    $id="0";
     $nama="Tidak terdaftar";
   $saldo="0";
   $saldo_akhir="0";
   $ambillokasi="Tidak Ada";
        $print_hasil = "KESALAHAN DATA";
    }


 


   	  	// $data = query("SELECT * FROM tabel_monitoring")[0];

		//UPDATE DATA REALTIME PADA TABEL tb_monitoring
		$sql      = "UPDATE tb_monitoring SET   rfid	= '$ambilrfid',status	= '$print_hasil', lokasi	= '$ambillokasi', golongan = '$ambilgolongan'";
		$koneksi->query($sql);
		
		//UPDATE DATA REALTIME PADA TABEL tb_realtime
		$sqlreal   = "UPDATE tb_realtime SET   tanggal ='$tgl', rfid	= '$ambilrfid',lokasi	= '$ambillokasi', golongan = '$ambilgolongan',status	= '$print_hasil'";
		$koneksi->query($sqlreal);
		
		
			
		//INSERT DATA REALTIME PADA TABEL tb_save  	
	
		$sqlsave = "INSERT INTO tb_simpan (tanggal,nama, rfid,lokasi,saldoawal,harga,saldoakhir,golongan,status) 
    VALUES ('" . $tgl . "', '" . $nama . "', '" . $ambilrfid . "', '" . $ambillokasi . "', '" . $saldo . "', '" . $harga3 . "', '" . $saldo_akhir . "', '" . $ambilgolongan . "', '" . $print_hasil . "')";
		$koneksi->query($sqlsave);

		//INSERT DATA REALTIME PADA TABEL tb_jumlah
		
		//MENJADIKAN JSON DATA
		//$response = query("SELECT * FROM tb_monitoring")[0];
   if($id!=0){
		      $response = query("SELECT * FROM tb_daftarrfid,tb_monitoring WHERE tb_daftarrfid.rfid='$ambilrfid'" )[0];
      	$result1 = json_encode($response);
		
     	echo $result1;}



 ?>
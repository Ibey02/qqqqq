<?php
require "koneksidb.php";	

// sql to delete a record
$sql  = "DELETE FROM tb_barang";
$sql2 = "UPDATE tb_monitoring SET jumlahkendaraan ='0'";
		$koneksi->query($sql2);

if ($koneksi->query($sql) === TRUE) {
  header("location:index.php");
} else {
  echo "Error deleting record: " . $koneksi->error;
}

$koneksi->close();
// mengalihkan ke halaman index.php
header("location:dashboard.php?pesan=berhasil");
?>